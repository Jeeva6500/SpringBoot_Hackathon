package com.natwest.exception;

public class UserNameAlreadyExist extends Exception {

	public UserNameAlreadyExist(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
