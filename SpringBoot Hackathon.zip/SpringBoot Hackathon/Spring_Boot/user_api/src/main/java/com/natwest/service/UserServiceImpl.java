package com.natwest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.natwest.exception.UserNameAlreadyExist;
import com.natwest.model.UserProfile;
import com.natwest.repo.UserRepository;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserRepository userRepo;

	@Override
	public UserProfile addUser(UserProfile userProfile) throws UserNameAlreadyExist {
		java.util.Optional<UserProfile> optUser = userRepo.findById(userProfile.getUsername());
		if (optUser.isPresent()) {
			throw new UserNameAlreadyExist("Username already exist!");
		}
		else {
			UserProfile temp = userRepo.save(userProfile);
			return temp;
		}
		
	
	}

	@Override
	public UserProfile updateUser(UserProfile userProfile) {
		UserProfile temp = userRepo.save(userProfile);
		return temp;
	}

	@Override
	public void deleteUser(String usename) {
		userRepo.deleteById(usename);
		
	}

	@Override
	public List<UserProfile> userList() {
		List<UserProfile> userList = (List<UserProfile>) userRepo.findAll();
		return userList;
	}

	@Override
	public UserProfile getByUserName(String username) {
		// TODO Auto-generated method stub
		return userRepo.findById(username).get();
	}

}
