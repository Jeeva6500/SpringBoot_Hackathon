package com.natwest.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.LinkedList;
import java.util.List;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.natwest.model.UserProfile;
import com.natwest.service.UserService;


@WebMvcTest
public class UserControllerTest {
	
	@Autowired
	MockMvc mockMvc;
	
	
	@MockBean
	UserService userServ;

	//convert the java object to json string format
	ObjectMapper mapper = new ObjectMapper();
	ObjectWriter writer = mapper.writer();
	
	List<UserProfile> userList = null;
	
	
	@BeforeEach
	void setUp() throws Exception {
		userList = new LinkedList<>();
		
		userList.add(new UserProfile("jeeva123@gmail.com", "jeeva@123", "Jeeva", "9633852741", "Bangalore", "123456789123"));
		userList.add(new UserProfile("suresh123@gmail.com", "suresh@123", "Suresh", "8522963741", "Chennai", "123456789124"));	
		userList.add(new UserProfile("geetha123@gmail.com", "geetha@123", "Geetha", "7418529633", "Mumbai", "123456789125"));
		userList.add(new UserProfile("payal123@gmail.com", "payal@123", "Payal", "7418529630", "Delhi", "123456789126"));
		userList.add(new UserProfile("venkat123@gmail.com", "venkat@123", "Venkat", "9633852742", "Kolkata", "123456789127"));
		
	}

	@AfterEach
	void tearDown() throws Exception {
		userList = null;
	}
	
	@Test
	void testAddUser() throws Exception {
		UserProfile userProfile = new UserProfile("ram123@gmail.com", "ram@123", "Ram", "9633852749", "Hyderabad", "123456789120");
		when(userServ.addUser(userProfile)).thenReturn(userProfile);
		
		//String content = writer.writeValueAsString(userProfile);
		//mockMvc.perform(post("/add").contentType(MediaType.APPLICATION_JSON).content(content)).andExpect(status().is(201));
	}

	@Test
	void testGetUserList() throws Exception {
//		Using mockito to return the fake list instead of the real list
		when(userServ.userList()).thenReturn(userList);
		
		//mockMvc.perform(get("/get").contentType(MediaType.APPLICATION_JSON)).andExpect(status().is(200));
		//.andExpect(jsonPath("$", Matchers.hasSize(5)))
		//.andExpect(jsonPath("$[3]", Matchers.notNullValue()))
		//.andExpect(jsonPath("$[4].sName", Matchers.is("Venkat")));

	}

	@Test
	void testgetByUserName() throws Exception {
		when(userServ.getByUserName("jeeva123@gmail.com")).thenReturn(new UserProfile("jeeva123@gmail.com", "jeeva@123", "Jeeva", "9633852741", "Bangalore", "123456789123"));
		
		//mockMvc.perform(get("/jeeva123@gmail.com").contentType(MediaType.APPLICATION_JSON)).andExpect(status().is(200))
		//.andExpect(jsonPath("$", Matchers.notNullValue())).andExpect(jsonPath("$.sName", Matchers.is("Jeeva")))
		//.andExpect(jsonPath("$.phone", Matchers.is("9633852741"))).andExpect(jsonPath("$.address", Matchers.notNullValue()));
	}
}
