package com.natwest.service;

import com.natwest.model.UserProfile;

public interface UserService {

	public UserProfile findByUsernameAndPassword(String username, String password);
}
