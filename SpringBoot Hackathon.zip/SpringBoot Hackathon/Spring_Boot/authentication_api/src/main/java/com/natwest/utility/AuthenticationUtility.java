package com.natwest.utility;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.natwest.model.UserProfile;
import com.natwest.service.UserService;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import jakarta.servlet.ServletException;

@Component
public class AuthenticationUtility {

	@Autowired
	UserService userService;
	
	static final long ExpiryTime = 1000*60*60;
public String generateToken(String uname, String pass) throws ServletException {
		
		if(uname == null || pass == null) {
			throw new ServletException("Please fill the username and password field");
		} else {
			UserProfile temp = userService.findByUsernameAndPassword(uname, pass);
			
			if(temp == null) {
				throw new ServletException("Username or password incorrect, please check and try again");
			}
			String jwtToken = Jwts
								.builder()
								.setSubject(uname)
								.setIssuedAt(new Date())
								.setExpiration(new Date(System.currentTimeMillis()+ExpiryTime))
								.signWith(SignatureAlgorithm.HS256, "mysecretkey")
								.compact();
			
			return jwtToken;
		}
	

}
}

