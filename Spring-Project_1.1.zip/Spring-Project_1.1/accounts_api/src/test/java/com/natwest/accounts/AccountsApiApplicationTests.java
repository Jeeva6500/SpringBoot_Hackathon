package com.natwest.accounts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
