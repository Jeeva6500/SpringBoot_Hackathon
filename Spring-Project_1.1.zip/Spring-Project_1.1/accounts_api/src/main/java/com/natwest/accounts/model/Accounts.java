package com.natwest.accounts.model;

import org.hibernate.mapping.Constraint;
import org.hibernate.mapping.ForeignKey;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "accounts")
public class Accounts {
	
	@Id
	@Column(nullable = false,length = 20)
	private String accountNo;
	private String accountType;
	private long balance;
	@org.hibernate.annotations.ForeignKey(name = "customerId")
	private long customerId;
	//Constraint fk_user ForeignKey (customerId) references UserProfile ("customerId");
	
	public Accounts() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Accounts(String accountNo, String accountType, long balance, long customerId) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.balance = balance;
		this.customerId = customerId;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return "Accounts [accountNo=" + accountNo + ", accountType=" + accountType + ", balance=" + balance
				+ ", customerId=" + customerId + "]";
	}
	
	

}
