package com.natwest.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.natwest.model.UserProfile;
import com.natwest.repo.UserRepository;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserRepository userRepo;
	
	
	@Override
	public Optional<UserProfile> findById(String customerId) {
		return userRepo.findById(customerId);
	}

}
