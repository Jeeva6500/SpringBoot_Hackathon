package com.natwest.service;

import java.util.Optional;

import com.natwest.model.UserProfile;

public interface UserService {

	public Optional<UserProfile> findById(String username);
}
