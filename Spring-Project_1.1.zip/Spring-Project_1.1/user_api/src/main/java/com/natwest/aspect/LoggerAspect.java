package com.natwest.aspect;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggerAspect {
	
	//to instantiate and create an object of logger
	Logger log = LoggerFactory.getLogger(this.getClass());

	@AfterThrowing(value = "execution(* com.natwest.controller.UserController.saveUser(..))", throwing = "e")
	public void logAfterAddTransExceptionOccured(JoinPoint joinPoint, Throwable e) {
		log.error(e.getMessage());
	}
	
	@AfterThrowing(value = "execution(* com.natwest.controller.UserController.getTransaction(..))", throwing = "e")
	public void logAfterGetTransactionExceptionOccured(JoinPoint joinPoint, Throwable e) {
		log.error("Exception cause" + e.getCause());
		log.error(e.getMessage());
	}
	
	@Around(value = "execution(* com.natwest.controller.UserController.saveUser(..))")
	public Object logAroundEntireApplication(ProceedingJoinPoint joinPoint) throws Throwable {
		log.info(joinPoint.getSignature().getDeclaringTypeName());
		log.info("Method arguments:" +joinPoint.getArgs());
		Object obj;
		try {
			obj= joinPoint.proceed();
			
			log.info("Output:" +obj);
		
		return obj;
		} catch (Throwable e) {
			throw e;
		}
	}
	
	@Around(value = "execution(* com.natwest.controller.UserController.gerUserList(..))")
		public Object logAroundAddTransaction(ProceedingJoinPoint joinPoint) throws Throwable {
			log.info(joinPoint.getSignature().getDeclaringTypeName());
			
			Object obj ;
			
			try {
				obj = joinPoint.proceed();
				log.info("Method output: " + obj);
				return obj;
			} catch (Exception ex) {
				throw ex;

			}
			
		}

}

