package com.natwest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.natwest.model.UserProfile;
import com.natwest.repo.UserRepository;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserRepository userRepo;

	@Override
	public UserProfile addUser(UserProfile userProfile) throws Exception {
		BCryptPasswordEncoder bcryptPasswordEncoder = new BCryptPasswordEncoder();
		String encryptPassword = bcryptPasswordEncoder.encode(userProfile.getPassword());
		java.util.Optional<UserProfile> optUser = userRepo.findById(userProfile.getUsername());
		
		if (optUser.isPresent()) {
			throw new Exception("Username already exist!");
		}
		else {
			userProfile.setPassword(encryptPassword);
			UserProfile temp = userRepo.save(userProfile);
			return temp;
		}
	}

	@Override
	public List<UserProfile> userList() {
		List<UserProfile> userList = (List<UserProfile>) userRepo.findAll();
		return userList;
	}

	@Override
	public UserProfile getByUserName(String username) {
		return userRepo.findById(username).get();
	}

}
