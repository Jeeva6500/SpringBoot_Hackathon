package com.natwest.service;

import java.util.List;

import com.natwest.model.UserProfile;

public interface UserService {
	
	public UserProfile addUser(UserProfile userProfile) throws Exception;
	
	public List<UserProfile> userList();
	
	public UserProfile getByUserName(String username);
	

}
